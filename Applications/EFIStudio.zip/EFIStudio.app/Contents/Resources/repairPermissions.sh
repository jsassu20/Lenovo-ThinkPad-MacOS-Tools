#!/bin/sh
diskutil repairPermissions /Volumes/$*/