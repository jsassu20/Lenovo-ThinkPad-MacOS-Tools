#!/bin/sh

echo "Simulating Writing PC-EVI v8 to $2"
cd $1
##echo "./startupfiletool $2 ./boot_v8"

sleep 1


echo "Writing boot1h to $2"
cd $1
##echo "dd if=./guid/boot1h of=$2 bs=512 count=1"


sleep 1


echo "Writing boot0 to $3"
cd $1
##echo "dd if=./guid/boot0 of=$3 bs=400 count=1"

sleep 1

echo "EFI v8 successfully installed."
sleep 1