#!/bin/sh

rm /Library/Preferences/SystemConfiguration/com.apple.Boot.plist
cp /tmp/com.apple.Boot.plist.tmp /Library/Preferences/SystemConfiguration/com.apple.Boot.plist