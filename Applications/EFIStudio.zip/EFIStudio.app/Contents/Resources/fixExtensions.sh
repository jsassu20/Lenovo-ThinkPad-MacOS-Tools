#!/bin/sh
chmod -R 755 /Volumes/$*/System/Library/Extensions/*.kext && chown -R root:wheel /Volumes/$*/System/Library/Extensions/*.kext && echo "Permissions fixed at: $*"