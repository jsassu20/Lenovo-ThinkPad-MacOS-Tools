#!/bin/sh
reboot